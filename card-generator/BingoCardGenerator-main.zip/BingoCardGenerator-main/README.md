BingoCardGenerator
==================

[![Build Status](https://travis-ci.org/cherdt/BingoCardGenerator.svg?branch=master)](https://travis-ci.org/cherdt/BingoCardGenerator)

A bingo card generator. This is the source for https://osric.com/bingo-card-generator/


Tests
-----

I have recently added automated tests using [TravisCI](https://travis-ci.org/). Tests include:

* [JSHint](http://jshint.com)
* [QUnit](https://qunitjs.com/)


History
-------

I created this circa 2011. I was trying to create Midtown Village Window Bingo and I didn't like any of the tools I found online. It took a few hours to build the first version.

It has been and continues to be a pleasant surprise to find that other people are using it for a variety of fun purposes (family reunions, birthday parties, classroom activities, etc.)! I have added additional features over the years as people request them.
